# import pyautogui,time
# import pyautogui as pg



# while True:
#     pyautogui.click(1064,805)
#     # time.sleep(0.5)
#     print(pg.position())
import pyautogui
import time

def click(): 
    time.sleep(0.5)     
    pyautogui.click(1064,805)

def main():
    for i in range(10):
        break
        
    #you can set how much times you have to click in range(no. of times to click) 
        click()
main()
# break
