import time
import sqlite3
import sched
import requests

scheduler = sched.scheduler(time.time, time.sleep)
conn  = sqlite3.connect("FaceRo.db")
cursor = conn.cursor()
def fetch_data():
    cursor.execute("select * from attendance where deleted is NULL")
    rows = cursor.fetchall()
    for row in rows:
        data = str(row[1]+'/'+row[2]+'/'+str(row[0])+'?')
        r = requests.post('http://waytohr.herokuapp.com/transaction/fingerprint_records_entry?box_id=3&fingerprint_records=' +data)
        print(data)
        #print(r.text)
        if r.text == 'done':
            print(r.text)
            result = cursor.execute("update attendance set deleted = 'true' where id="+str(row[0]))
            conn.commit()
            #print(result)
        #print ('1')
while True:
    scheduler.enter(5,1,fetch_data)
    scheduler.run()
    
    